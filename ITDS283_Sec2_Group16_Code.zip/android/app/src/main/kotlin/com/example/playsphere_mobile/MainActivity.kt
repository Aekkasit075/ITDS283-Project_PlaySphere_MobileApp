package com.example.playsphere_mobile

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity() {
    
}
