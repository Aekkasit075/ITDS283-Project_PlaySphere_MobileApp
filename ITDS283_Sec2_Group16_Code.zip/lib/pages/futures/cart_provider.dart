import 'package:flutter/material.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'dart:convert'; // ใช้สำหรับแปลง List เป็น String และกลับกัน

class CartProvider with ChangeNotifier {
  List<Map<String, dynamic>> _items = [];

  List<Map<String, dynamic>> get items => _items;

  double get totalPrice => _items.fold(0.0, (sum, item) {
    final priceStr = item["price"].toString();
    double price = 0.0;

    if (priceStr.toLowerCase() == "free") {
      price = 0.0;
    } else {
      if (priceStr.startsWith("THB")) {
        price = double.tryParse(priceStr.replaceFirst("THB", "").trim()) ?? 0.0;
      } else {
        price = double.tryParse(priceStr) ?? 0.0;
      }
    }

    return sum + price;
  });

  CartProvider() {
    _loadCart();
  }

  void addItem(Map<String, dynamic> item) {
    _items.add(item);
    notifyListeners();
    _saveCart();
  }

  void removeItem(String id) {
    _items.removeWhere((item) => item["id"] == id);
    notifyListeners();
    _saveCart();
  }

  void clearCart() {
    _items.clear();
    notifyListeners();
    _saveCart();
  }

  // ลบหลายรายการตาม id ที่ส่งมา
  void removeItemsByIds(List<String> ids) {
    _items.removeWhere((item) => ids.contains(item["id"].toString()));
    notifyListeners();
    _saveCart();
  }

  // โหลดข้อมูลตะกร้า จาก SharedPreferences
  Future<void> _loadCart() async {
    SharedPreferences prefs = await SharedPreferences.getInstance();
    String? itemsString = prefs.getString('cart_items');

    if (itemsString != null) {
      List<dynamic> decodedList = jsonDecode(itemsString);
      _items =
          decodedList.map((item) => Map<String, dynamic>.from(item)).toList();
      notifyListeners();
    }
  }

  // บันทึกข้อมูลตะกร้า ลง SharedPreferences
  Future<void> _saveCart() async {
    SharedPreferences prefs = await SharedPreferences.getInstance();
    String encodedItems = jsonEncode(_items);
    await prefs.setString('cart_items', encodedItems);
  }
}
