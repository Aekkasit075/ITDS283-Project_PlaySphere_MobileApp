import 'package:flutter/material.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:provider/provider.dart';
import 'package:http/http.dart' as http;
import 'CheckOutPage.dart';
import '../MyCartPage.dart';
import 'user_model.dart';
import '../../config.dart';
import 'cart_provider.dart';


class PaymentPage extends StatefulWidget {
  final UserModel user;
  final String selectedPaymentMethod;
  final List<Map<String, dynamic>> cartItems;
  final double totalPrice;

  const PaymentPage({
    super.key,
    required this.selectedPaymentMethod,
    required this.user,
    required this.cartItems,
    required this.totalPrice,
  });

  @override
  _PaymentPageState createState() => _PaymentPageState();
}

class _PaymentPageState extends State<PaymentPage> {
  bool isChecked = false;

  Future<void> _updateGamesPriceToFree() async {
    for (var item in widget.cartItems) {
      try {
        int gameId = int.parse(item['id']);
         
        var url = Uri.parse('${AppConfig.baseUrl}/edit_game/$gameId');

        var request = http.MultipartRequest('PUT', url)
          ..fields['price'] = 'free'; // เปลี่ยนราคาเป็น free

        var response = await request.send();

        if (response.statusCode == 200) {
          print('Updated game $gameId to free successfully.');
        } else {
          print('Failed to update game $gameId: ${response.statusCode}');
        }
      } catch (e) {
        print('Error updating game: $e');
      }
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: const Color(0xFF205568),
      appBar: AppBar(
        backgroundColor: const Color(0xFF205568),
        elevation: 0,
        title: const Text(
          'หน้าชำระเงิน',
          style: TextStyle(
            color: Colors.white,
            fontSize: 18,
            fontWeight: FontWeight.bold,
          ),
        ),
        leading: IconButton(
          icon: const Icon(Icons.arrow_back, color: Colors.white),
          onPressed: () => Navigator.of(context).pop(),
        ),
      ),
      body: Container(
        width: double.infinity,
        height: double.infinity,
        color: const Color(0xFF1F5B64),
        child: Padding(
          padding: const EdgeInsets.all(16.0),
          child: Container(
            padding: const EdgeInsets.all(16.0),
            decoration: BoxDecoration(
              color: const Color(0xFF4D4C52),
              borderRadius: BorderRadius.circular(8.0),
            ),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                // สร้าง Card สำหรับแสดงสินค้าทั้งหมดใน cartItems
                ...widget.cartItems
                    .map((item) => _buildItemCard(item))
                    .toList(),
                const SizedBox(height: 10),
                _buildSummary(),
                const SizedBox(height: 10),
                Container(height: 20, color: Colors.white),
                const SizedBox(height: 10),
                _buildPaymentMethod(),
                const Spacer(),
                _buildConfirmButton(),
              ],
            ),
          ),
        ),
      ),
    );
  }

  // สร้าง widget สำหรับแสดงสินค้าใน cartItems
  Widget _buildItemCard(Map<String, dynamic> item) {
    return Column(
      children: [
        Padding(
          padding: const EdgeInsets.symmetric(vertical: 5),
          child: Row(
            children: [
              ClipRRect(
                borderRadius: BorderRadius.circular(10), // ทำให้รูปมุมมน
                child: Image.network(
                  '${AppConfig.baseUrl}/${item["game_profile"]}', // รูปเกม
                  width: 80.w,
                  height: 80.h,
                  fit: BoxFit.cover, // ให้รูปเต็ม container แบบสวยงาม
                  errorBuilder:
                      (context, error, stackTrace) => Container(
                        width: 80.w,
                        height: 80.h,
                        color: Colors.grey[300],
                        child: Icon(Icons.broken_image, size: 40),
                      ),
                ),
              ),
              const SizedBox(width: 10),
              Expanded(
                child: Text(
                  item['name'] ?? 'Name', // ใช้ชื่อสินค้าที่อยู่ใน cartItem
                  style: TextStyle(
                    fontSize: 16,
                    fontWeight: FontWeight.bold,
                    color: Colors.white,
                  ),
                ),
              ),
              Text(
                '${item['price']}', // แสดงราคาของสินค้า
                style: TextStyle(
                  fontSize: 16,
                  fontWeight: FontWeight.bold,
                  color: Colors.white,
                ),
              ),
            ],
          ),
        ),
        const Divider(color: Colors.white, thickness: 1), // เส้นใต้
      ],
    );
  }

  // แสดงสรุปรายการทั้งหมด
  Widget _buildSummary() {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        const Text(
          'สรุปรายการ:',
          style: TextStyle(fontWeight: FontWeight.bold, color: Colors.white),
        ),
        const SizedBox(height: 5),
        // แสดงรายการทั้งหมดใน cartItems
        ...widget.cartItems.map((item) {
          return Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              Text('- ${item['name']}', style: TextStyle(color: Colors.white)),
              Text('${item['price']}', style: TextStyle(color: Colors.white)),
            ],
          );
        }).toList(),
        const Divider(color: Colors.white, thickness: 1),
        Row(
          mainAxisAlignment: MainAxisAlignment.spaceBetween,
          children: [
            const Text(
              'รวมทั้งหมด',
              style: TextStyle(
                fontWeight: FontWeight.bold,
                color: Colors.white,
              ),
            ),
            Text(
              'THB${widget.totalPrice}', // แสดงยอดรวม
              style: const TextStyle(
                fontWeight: FontWeight.bold,
                color: Colors.white,
              ),
            ),
          ],
        ),
      ],
    );
  }

  // แสดงวิธีการชำระเงินที่เลือก
  Widget _buildPaymentMethod() {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Row(
          children: [
            Expanded(
              child: Text(
                'วิธีชำระเงิน: ${widget.selectedPaymentMethod.isNotEmpty ? widget.selectedPaymentMethod : "ไม่ระบุ"}',
                style: const TextStyle(
                  fontWeight: FontWeight.bold,
                  color: Colors.white,
                ),
              ),
            ),
            GestureDetector(
              onTap: () {
                Navigator.pushReplacement(
                  context,
                  MaterialPageRoute(
                    builder:
                        (context) => CheckOutPage(
                          user: widget.user,
                          cartItems: widget.cartItems,
                          totalPrice: widget.totalPrice,
                        ),
                  ),
                );
              },
              child: const Text(
                '(เปลี่ยน)',
                style: TextStyle(
                  color: Colors.white,
                  fontWeight: FontWeight.bold,
                  decoration: TextDecoration.underline,
                  decorationColor: Colors.white,
                ),
              ),
            ),
          ],
        ),
        const SizedBox(height: 10),
        Row(
          children: [
            Checkbox(
              value: isChecked,
              onChanged: (value) {
                setState(() {
                  isChecked = value!;
                });
              },
              activeColor: Colors.green,
              checkColor: Colors.white,
            ),
            const Expanded(
              child: Text(
                'ยอมรับข้อกำหนดของการชำระเงิน เมื่อตกลงคำสั่งข้างล่าง จะดำเนินธุรกรรมต่อไป',
                style: TextStyle(color: Colors.white),
              ),
            ),
          ],
        ),
      ],
    );
  }

  // ปุ่มยืนยันการสั่งซื้อ
  Widget _buildConfirmButton() {
    return Center(
      child: ElevatedButton(
        style: ElevatedButton.styleFrom(
          backgroundColor: isChecked ? Colors.green : Color(0xFFA2A2A2),
          padding: const EdgeInsets.symmetric(horizontal: 50, vertical: 15),
          shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(8)),
        ),
        onPressed: isChecked ? _showPaymentSuccessDialog : null,
        child: const Text(
          'ยืนยันการสั่งซื้อ',
          style: TextStyle(color: Colors.white, fontWeight: FontWeight.bold),
        ),
      ),
    );
  }

  // แสดง Dialog เมื่อการชำระเงินสำเร็จ
  void _showPaymentSuccessDialog() async {
    // 1. อัปเดตราคาเป็น Free ก่อน
    await _updateGamesPriceToFree();
    showDialog(
      context: context,
      builder: (BuildContext context) {
        return AlertDialog(
          shape: RoundedRectangleBorder(
            borderRadius: BorderRadius.circular(15),
          ),
          content: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              const Icon(Icons.check_circle, color: Colors.green, size: 30),
              const SizedBox(height: 10),
              const Text(
                'ชำระเงินสำเร็จ',
                style: TextStyle(fontWeight: FontWeight.bold),
              ),
              const SizedBox(height: 20),
              ElevatedButton(
                style: ElevatedButton.styleFrom(
                  backgroundColor: Colors.blue,
                  shape: RoundedRectangleBorder(
                    borderRadius: BorderRadius.circular(10),
                  ),
                ),
                onPressed: () {
                  // เคลียร์ cart ใน Provider
                  List<String> idsToRemove = widget.cartItems.map((item) => item['id'].toString()).toList();
                  Provider.of<CartProvider>(context, listen: false).removeItemsByIds(idsToRemove);

                  Navigator.pushReplacement(
                    context,
                    MaterialPageRoute(
                      builder: (context) => MyCartPage(user: widget.user),
                    ), // Navigate to MyCartPage
                  );
                },
                child: const Text('OK', style: TextStyle(color: Colors.white)),
              ),
            ],
          ),
        );
      },
    );
  }
}
