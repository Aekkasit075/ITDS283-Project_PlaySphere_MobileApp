class UserModel {
  final String token;
  final String username;
  final String profilePicture; // เพิ่มที่นี้
  final String password;
  final String email;

  UserModel({
    required this.token,
    required this.username,
    required this.profilePicture, // เพิ่มที่นี้
    required this.password,
    required this.email,
  });

  factory UserModel.fromJson(Map<String, dynamic> json) {
    return UserModel(
      token: json['token'] ?? '',
      username: json['username'] ?? 'Unknown',
      profilePicture: json['profile_picture'], 
      email: json['email'] ?? '',
      password: json['password'] ?? '',
    );
  }

  // เพิ่ม copyWith เพื่ออัปเดต profilePicture
  UserModel copyWith({
    String? token,
    String? username,
    String? profilePicture, // เพิ่มที่นี้
    String? password,
    String? email,
  }) {
    return UserModel(
      token: token ?? this.token,
      username: username ?? this.username,
      profilePicture: profilePicture ?? this.profilePicture, // เพิ่มที่นี้
      password: password ?? this.password,
      email: email ?? this.email,
    );
  }
}
