import 'package:flutter/material.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:provider/provider.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'dart:convert';
import '../MyCartPage.dart';
import '../../config.dart';
import 'user_model.dart';
import 'cart_provider.dart';

class DetailPage extends StatefulWidget {
  final UserModel user;
  final Map<String, String> app;

  const DetailPage({Key? key, required this.app, required this.user})
    : super(key: key);

  @override
  State<DetailPage> createState() => _DetailPageState();
}

class _DetailPageState extends State<DetailPage> {
  List<Map<String, String>> comments = [];
  bool isDownloading = false;
  bool isDownloaded = false;

  @override
  void initState() {
    super.initState();
    _checkIfDownloaded();
    loadComments().then((_) {
    setState(() {});
  });
  }

  Future<void> _checkIfDownloaded() async {
    SharedPreferences prefs = await SharedPreferences.getInstance();
    List<String> downloadedGames =
        prefs.getStringList('downloaded_games') ?? [];

    final currentGameId = widget.app["id"];
    final found = downloadedGames.any((item) {
      final game = jsonDecode(item);
      return game["id"] == currentGameId;
    });

    setState(() {
      isDownloaded = found;

      // ถ้าเกมถูกบันทึกไว้ เราควรอัปเดตราคาใน app["price"] ด้วย (ในกรณีแสดงไม่ตรง)
      if (found) {
        widget.app["price"] = "Play";
      }
    });
  }

  Future<void> loadComments() async {
    SharedPreferences prefs = await SharedPreferences.getInstance();
    String? data = prefs.getString(widget.app["id"]!);  // Use the app's id as key
    if (data != null) {
      List<dynamic> jsonList = json.decode(data);
      comments = jsonList.map((e) => Map<String, String>.from(e)).toList();
    }
  }

  Future<void> saveComments() async {
    SharedPreferences prefs = await SharedPreferences.getInstance();
    await prefs.setString(widget.app["id"]!, json.encode(comments));  // Save with app id as key
  }


  void _showCommentDialog(BuildContext context) {
    TextEditingController _controller = TextEditingController();

    showDialog(
      context: context,
      builder: (BuildContext context) {
        return AlertDialog(
          backgroundColor: Colors.grey[200],
          shape: RoundedRectangleBorder(
            borderRadius: BorderRadius.circular(10),
          ),
          contentPadding: EdgeInsets.all(20),
          content: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              // Header
              Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: [
                  IconButton(
                    icon: Icon(Icons.arrow_back),
                    onPressed: () => Navigator.pop(context),
                  ),
                  Row(
                    children: [
                      Text(
                        widget.user.username,
                        style: TextStyle(fontWeight: FontWeight.bold),
                      ),
                      SizedBox(width: 5),
                      Icon(Icons.account_circle),
                    ],
                  ),
                ],
              ),
              SizedBox(height: 10),
              // Text Field
              TextField(
                controller: _controller,
                maxLines: 5,
                decoration: InputDecoration(
                  hintText: "พิมพ์สิ่งที่คุณต้องการบอกผู้อื่น...",
                  border: OutlineInputBorder(),
                  filled: true,
                  fillColor: Colors.white,
                ),
              ),
              SizedBox(height: 20),
              // Message Button
              Align(
                alignment: Alignment.centerRight,
                child: ElevatedButton(
                  onPressed: () async {
                    if (_controller.text.trim().isNotEmpty) {
                      setState(() {
                        comments.add({
                          "user": widget.user.username,
                          "text": _controller.text.trim(),
                        });
                      });
                      await saveComments();
                    }
                    Navigator.pop(context);
                  },
                  style: ElevatedButton.styleFrom(
                    backgroundColor: Colors.lightBlue,
                    shape: RoundedRectangleBorder(
                      borderRadius: BorderRadius.circular(20),
                    ),
                  ),
                  child: Text("message"),
                ),
              ),
            ],
          ),
        );
      },
    );
  }

  @override
  Widget build(BuildContext context) {
    final app = widget.app;

    Future<void> _saveDownloadedGame() async {
      SharedPreferences prefs = await SharedPreferences.getInstance();
      List<String> downloadedGames =
          prefs.getStringList('downloaded_games') ?? [];

      // ลบรายการเก่า (ถ้ามี id ซ้ำกัน)
      downloadedGames.removeWhere((item) {
        final game = jsonDecode(item);
        return game["id"] == widget.app["id"];
      });

      // กำหนดราคาเป็น "Play"
      final updatedApp = Map<String, String>.from(widget.app);
      updatedApp["price"] = "Play";
      downloadedGames.add(jsonEncode(updatedApp));

      await prefs.setStringList('downloaded_games', downloadedGames);
    }

    return Scaffold(
      backgroundColor: Color(0xFF205568),
      appBar: AppBar(
        backgroundColor: Colors.grey[300],
        elevation: 0,
        leading: IconButton(
          icon: Icon(Icons.arrow_back, color: Colors.black),
          onPressed: () => Navigator.pop(context),
        ),
      ),
      body: SingleChildScrollView(
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            // Banner
            Container(
              width: double.infinity,
              height: 150.h,
              decoration: BoxDecoration(
                color: Colors.grey[400],
                image:
                    app['banner_image'] != null
                        ? DecorationImage(
                          image: NetworkImage(
                            '${AppConfig.baseUrl}/${app["banner_image"]}',
                          ),
                          fit: BoxFit.cover,
                        )
                        : null,
              ),
            ),
            Padding(
              padding: const EdgeInsets.all(10.0),
              child: Row(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  // Game Profile (icon รูปเกมเล็ก)
                  ClipRRect(
                    borderRadius: BorderRadius.circular(10),
                    child: Image.network(
                      '${AppConfig.baseUrl}/${app["game_profile"]}',
                      width: 50.h,
                      height: 50.h,
                      fit: BoxFit.cover,
                      errorBuilder:
                          (context, error, stackTrace) => Container(
                            width: 50.h,
                            height: 50.h,
                            color: Colors.white,
                            child: Icon(Icons.broken_image),
                          ),
                    ),
                  ),
                  SizedBox(width: 10),
                  Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(
                        app["name"] ?? "Unknown",
                        style: TextStyle(color: Colors.white, fontSize: 16),
                      ),
                      Text(
                        "ยอดดาวน์โหลด ${app["downloads"]}",
                        style: TextStyle(color: Colors.white70, fontSize: 12),
                      ),
                    ],
                  ),
                  Spacer(),
                  Column(
                    children: [
                      Text(
                        "พื้นที่ ${app["size"]}",
                        style: TextStyle(color: Colors.white70, fontSize: 12),
                      ),
                      SizedBox(height: 5),
                      ElevatedButton(
                        onPressed: () async {
                          final price = app["price"] ?? "";

                          // 👉 กรณีเป็นราคาที่ต้องซื้อ
                          if (price.startsWith("THB")) {
                            showDialog(
                              context: context,
                              builder: (context) {
                                return Dialog(
                                  shape: RoundedRectangleBorder(
                                    side: BorderSide(
                                      color: Color(0xFF4D4C52),
                                      width: 4,
                                    ),
                                    borderRadius: BorderRadius.circular(10),
                                  ),
                                  backgroundColor: Colors.white,
                                  child: Padding(
                                    padding: const EdgeInsets.all(20.0),
                                    child: Column(
                                      mainAxisSize: MainAxisSize.min,
                                      children: [
                                        Container(
                                          decoration: BoxDecoration(
                                            color: Color(0xFF4D4C52),
                                            borderRadius: BorderRadius.circular(
                                              10,
                                            ),
                                          ),
                                          padding: EdgeInsets.symmetric(
                                            vertical: 10,
                                            horizontal: 15,
                                          ),
                                          child: Row(
                                            mainAxisAlignment:
                                                MainAxisAlignment.spaceBetween,
                                            children: [
                                              Text(
                                                "Put in your cart!!!",
                                                style: TextStyle(
                                                  color: Colors.white,
                                                  fontWeight: FontWeight.bold,
                                                ),
                                              ),
                                              GestureDetector(
                                                onTap:
                                                    () =>
                                                        Navigator.pop(context),
                                                child: Text(
                                                  "back",
                                                  style: TextStyle(
                                                    color: Colors.grey[300],
                                                  ),
                                                ),
                                              ),
                                            ],
                                          ),
                                        ),
                                        SizedBox(height: 20),
                                        Row(
                                          mainAxisAlignment:
                                              MainAxisAlignment.spaceBetween,
                                          crossAxisAlignment:
                                              CrossAxisAlignment.start,
                                          children: [
                                            ClipRRect(
                                              borderRadius:
                                                  BorderRadius.circular(10),
                                              child: Image.network(
                                                '${AppConfig.baseUrl}/${widget.app["game_profile"]}',
                                                width: 80,
                                                height: 80,
                                                fit: BoxFit.cover,
                                                errorBuilder:
                                                    (
                                                      context,
                                                      error,
                                                      stackTrace,
                                                    ) => Container(
                                                      width: 80,
                                                      height: 80,
                                                      color: Colors.white,
                                                      child: Icon(
                                                        Icons.broken_image,
                                                      ),
                                                    ),
                                              ),
                                            ),
                                            SizedBox(width: 10),
                                            Expanded(
                                              child: Column(
                                                crossAxisAlignment:
                                                    CrossAxisAlignment.start,
                                                children: [
                                                  Text(
                                                    app["name"] ?? "Unknown",
                                                    style: TextStyle(
                                                      color: Colors.black,
                                                      fontWeight:
                                                          FontWeight.bold,
                                                    ),
                                                  ),
                                                  SizedBox(height: 5),
                                                  Text(
                                                    "พื้นที่ ${app["size"] ?? ""}",
                                                    style: TextStyle(
                                                      color: Colors.black54,
                                                    ),
                                                  ),
                                                  SizedBox(height: 10),
                                                  Text(
                                                    app["price"] ?? "",
                                                    style: TextStyle(
                                                      color: Colors.black,
                                                      fontWeight:
                                                          FontWeight.bold,
                                                    ),
                                                  ),
                                                ],
                                              ),
                                            ),
                                          ],
                                        ),
                                        SizedBox(height: 20),
                                        Row(
                                          mainAxisAlignment:
                                              MainAxisAlignment.end,
                                          children: [
                                            ElevatedButton(
                                              onPressed: () {
                                                Navigator.pop(context);
                                                final cartItem = {
                                                  'id': app["id"],
                                                  'name': app["name"],
                                                  'size': app["size"],
                                                  'price': app["price"],
                                                  'game_profile':
                                                      app["game_profile"],
                                                };
                                                Provider.of<CartProvider>(
                                                  context,
                                                  listen: false,
                                                ).addItem(cartItem);

                                                showDialog(
                                                  context: context,
                                                  builder: (context) {
                                                    return Dialog(
                                                      shape: RoundedRectangleBorder(
                                                        side: BorderSide(
                                                          color: Color(
                                                            0xFF5C4033,
                                                          ),
                                                          width: 4,
                                                        ),
                                                        borderRadius:
                                                            BorderRadius.circular(
                                                              10,
                                                            ),
                                                      ),
                                                      backgroundColor:
                                                          Colors.white,
                                                      child: Padding(
                                                        padding:
                                                            const EdgeInsets.all(
                                                              20.0,
                                                            ),
                                                        child: Column(
                                                          mainAxisSize:
                                                              MainAxisSize.min,
                                                          children: [
                                                            Text(
                                                              "Put in your cart!!!",
                                                              style: TextStyle(
                                                                color:
                                                                    Colors
                                                                        .black,
                                                                fontWeight:
                                                                    FontWeight
                                                                        .bold,
                                                              ),
                                                            ),
                                                            SizedBox(
                                                              height: 20,
                                                            ),
                                                            Icon(
                                                              Icons
                                                                  .check_circle_outline,
                                                              color:
                                                                  Colors.green,
                                                              size: 50,
                                                            ),
                                                            SizedBox(
                                                              height: 10,
                                                            ),
                                                            Text(
                                                              "เพิ่มลงรถเข็นสำเร็จแล้ว",
                                                              style: TextStyle(
                                                                color:
                                                                    Colors
                                                                        .black,
                                                              ),
                                                            ),
                                                            SizedBox(
                                                              height: 20,
                                                            ),
                                                            Row(
                                                              mainAxisAlignment:
                                                                  MainAxisAlignment
                                                                      .spaceEvenly,
                                                              children: [
                                                                TextButton(
                                                                  onPressed:
                                                                      () => Navigator.pop(
                                                                        context,
                                                                      ),
                                                                  style: ElevatedButton.styleFrom(
                                                                    backgroundColor:
                                                                        Color(
                                                                          0xFF4D4C52,
                                                                        ),
                                                                    shape: RoundedRectangleBorder(
                                                                      borderRadius:
                                                                          BorderRadius.circular(
                                                                            10,
                                                                          ),
                                                                    ),
                                                                  ),
                                                                  child: Text(
                                                                    "ตกลง",
                                                                    style: TextStyle(
                                                                      color:
                                                                          Colors
                                                                              .white,
                                                                    ),
                                                                  ),
                                                                ),
                                                                ElevatedButton(
                                                                  onPressed: () {
                                                                    Navigator.pop(
                                                                      context,
                                                                    );
                                                                    Navigator.push(
                                                                      context,
                                                                      MaterialPageRoute(
                                                                        builder:
                                                                            (
                                                                              _,
                                                                            ) => MyCartPage(
                                                                              user:
                                                                                  widget.user,
                                                                            ),
                                                                      ),
                                                                    );
                                                                  },
                                                                  style: ElevatedButton.styleFrom(
                                                                    backgroundColor:
                                                                        Colors
                                                                            .blue,
                                                                    shape: RoundedRectangleBorder(
                                                                      borderRadius:
                                                                          BorderRadius.circular(
                                                                            10,
                                                                          ),
                                                                    ),
                                                                  ),
                                                                  child: Text(
                                                                    "ดูตะกร้า",
                                                                    style: TextStyle(
                                                                      color:
                                                                          Colors
                                                                              .white,
                                                                    ),
                                                                  ),
                                                                ),
                                                              ],
                                                            ),
                                                          ],
                                                        ),
                                                      ),
                                                    );
                                                  },
                                                );
                                              },
                                              style: ElevatedButton.styleFrom(
                                                backgroundColor: Colors.blue,
                                                shape: RoundedRectangleBorder(
                                                  borderRadius:
                                                      BorderRadius.circular(10),
                                                ),
                                              ),
                                              child: Text(
                                                "เพิ่มลงตะกร้า",
                                                style: TextStyle(
                                                  color: Colors.white,
                                                ),
                                              ),
                                            ),
                                          ],
                                        ),
                                      ],
                                    ),
                                  ),
                                );
                              },
                            );
                            return; // 🛑 หยุดตรงนี้เลย ถ้าเป็น THB
                          }

                          // 🎯 เฉพาะ Free กับ Play เท่านั้นที่เข้ามาตรงนี้
                          if (!isDownloading) {
                            setState(() {
                              isDownloading = true;
                            });

                            await Future.delayed(Duration(seconds: 2));

                            if (price == "Free") {
                              setState(() {
                                app["price"] = "Play";
                                isDownloaded = true;
                              });
                              await _saveDownloadedGame();
                            } else if (price == "Play") {
                              setState(() {
                                app["price"] = "Free";
                                isDownloaded = false;
                              });

                              SharedPreferences prefs =
                                  await SharedPreferences.getInstance();
                              List<String> downloadedGames =
                                  prefs.getStringList('downloaded_games') ?? [];
                              downloadedGames.removeWhere((item) {
                                final game = jsonDecode(item);
                                return game["id"] == app["id"];
                              });
                              await prefs.setStringList(
                                'downloaded_games',
                                downloadedGames,
                              );

                              print('เกมถูกลบออกจากเครื่องแล้ว');
                            }

                            setState(() {
                              isDownloading = false;
                            });
                          }
                        },
                        style: ElevatedButton.styleFrom(
                          backgroundColor: Colors.blue,
                          shape: RoundedRectangleBorder(
                            borderRadius: BorderRadius.circular(20),
                          ),
                          padding: EdgeInsets.symmetric(
                            horizontal: 20,
                            vertical: 10,
                          ),
                        ),
                        child: Builder(
                          builder: (context) {
                            if (isDownloaded) {
                              return Text("Play");
                            } else if (isDownloading) {
                              return SizedBox(
                                width: 20,
                                height: 20,
                                child: CircularProgressIndicator(
                                  color: Colors.white,
                                  strokeWidth: 2,
                                ),
                              );
                            } else {
                              return Text(app["price"] ?? "N/A");
                            }
                          },
                        ),
                      ),
                    ],
                  ),
                ],
              ),
            ),
            Divider(color: Colors.white30),

            // Review Section
            Padding(
              padding: const EdgeInsets.symmetric(horizontal: 10),
              child: Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: [
                  Text("Review", style: TextStyle(color: Colors.white)),
                  GestureDetector(
                    onTap: () => _showCommentDialog(context),
                    child: Text(
                      "comment",
                      style: TextStyle(color: Colors.white),
                    ),
                  ),
                ],
              ),
            ),
            comments.isEmpty
                ? Container(
                  margin: EdgeInsets.all(10),
                  padding: EdgeInsets.all(20),
                  width: double.infinity,
                  color: Colors.teal[700],
                  child: Text(
                    "unreview...",
                    style: TextStyle(color: Colors.white),
                  ),
                )
                : SingleChildScrollView(
                  scrollDirection: Axis.horizontal,
                  padding: EdgeInsets.symmetric(vertical: 10, horizontal: 10),
                  child: Row(
                    children:
                        comments.map((c) {
                          return Container(
                            margin: EdgeInsets.only(right: 10),
                            padding: EdgeInsets.all(15),
                            width: 200,
                            color: Colors.teal[700],
                            child: Column(
                              crossAxisAlignment: CrossAxisAlignment.start,
                              children: [
                                Row(
                                  children: [
                                    Icon(
                                      Icons.account_circle,
                                      color: Colors.white,
                                    ),
                                    SizedBox(width: 5),
                                    Text(
                                      c["user"]!,
                                      style: TextStyle(
                                        color: Colors.white,
                                        fontWeight: FontWeight.bold,
                                      ),
                                    ),
                                  ],
                                ),
                                SizedBox(height: 10),
                                Text(
                                  c["text"]!,
                                  style: TextStyle(color: Colors.white),
                                ),
                              ],
                            ),
                          );
                        }).toList(),
                  ),
                ),

            // Screenshot Section
            Padding(
              padding: const EdgeInsets.symmetric(horizontal: 10),
              child: Align(
                alignment: Alignment.centerLeft,
                child: Text(
                  "Screenshots",
                  style: TextStyle(color: Colors.white),
                ),
              ),
            ),
            SizedBox(height: 10),
            SingleChildScrollView(
              scrollDirection: Axis.horizontal,
              padding: const EdgeInsets.symmetric(horizontal: 10),
              child: Row(
                children: [
                  // ตรวจสอบว่า app["screenshot_image"] ไม่เป็นค่าว่าง
                  ...(app["screenshot_images"] != null &&
                          app["screenshot_images"]!.isNotEmpty
                      ? app["screenshot_images"]!
                          .split(',') // แบ่งสตริงจากคอมม่าเพื่อแยก URL
                          .map((screenshotUrl) {
                            return Container(
                              margin: EdgeInsets.only(right: 10),
                              width: 200,
                              height: 120,
                              decoration: BoxDecoration(
                                color: Colors.grey[400],
                                borderRadius: BorderRadius.circular(10),
                                image: DecorationImage(
                                  image: NetworkImage(
                                    '${AppConfig.baseUrl}/$screenshotUrl',
                                  ),
                                  fit: BoxFit.cover,
                                  onError: (error, stackTrace) {
                                    // ถ้าโหลดรูปไม่ได้
                                    print(
                                      'Error loading screenshot image: $error',
                                    );
                                  },
                                ),
                              ),
                            );
                          })
                          .toList()
                      : [Container()]), // กรณีไม่มี screenshot
                ],
              ),
            ),

            SizedBox(height: 20),

            // Description
            Padding(
              padding: const EdgeInsets.symmetric(horizontal: 10),
              child: Align(
                alignment: Alignment.centerLeft,
                child: Text("คำอธิบาย", style: TextStyle(color: Colors.white)),
              ),
            ),
            SizedBox(height: 10),
            Padding(
              padding: const EdgeInsets.all(10.0),
              child: Text(
                "${app["description"]}",
                style: TextStyle(color: Colors.white),
              ),
            ),
          ],
        ),
      ),
    );
  }
}
