class AppConfig {
  static const String baseUrl = "http://192.168.56.1:5000"; // 🔁 Replace with your IP
}