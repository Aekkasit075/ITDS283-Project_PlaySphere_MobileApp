from db_config import get_db_connection
import hashlib
import uuid

def generate_token():
    return str(uuid.uuid4())

def hash_password(password):
    return hashlib.sha256(password.encode()).hexdigest()

def register_user(email, password, username):
    # ตั้ง default profile picture
    default_profile_picture = "default.png"
    hashed_password = hash_password(password)
    conn = get_db_connection()
    cursor = conn.cursor()
    query = """
        INSERT INTO users (email, password, username, profile_picture)
        VALUES (%s, %s, %s, %s)
    """
    values = (email, hashed_password, username, default_profile_picture)
    cursor.execute(query, values)
    conn.commit()
    cursor.close()
    conn.close()

def update_user_profile(user_id, update_data):
    if not update_data:
        return  # ไม่มีอะไรให้อัปเดต

    connection = get_db_connection()
    cursor = connection.cursor()

    # สร้าง query แบบไดนามิกตาม key ของ update_data
    set_clause = ', '.join([f"{key} = %s" for key in update_data])
    values = list(update_data.values())
    values.append(user_id)

    query = f"""
        UPDATE users
        SET {set_clause}
        WHERE id = %s
    """

    cursor.execute(query, values)
    connection.commit()
    connection.close()


def get_user_id_by_email(email):
    connection = get_db_connection()
    cursor = connection.cursor()
    cursor.execute("SELECT id FROM users WHERE email = %s", (email,))
    result = cursor.fetchone()
    connection.close()
    return result[0] if result else None


def get_user_by_email(email):
    conn = get_db_connection()
    cursor = conn.cursor(buffered=True)
    query = "SELECT email, password, username, profile_picture FROM users WHERE email = %s"
    cursor.execute(query, (email,))
    user = cursor.fetchone()
    cursor.close()
    conn.close()
    return user

def login_user(email, password):
    user = get_user_by_email(email)
    if user:
        # เปรียบเทียบรหัสผ่านที่ถูกแฮชแล้ว
        if user[1] == hash_password(password):  # user[1] คือ password ที่เก็บในฐานข้อมูล
            token = generate_token()  # สร้าง token ใหม่
            return True, token, user[2], user[3]  # คืนค่า True, token, username, profile_picture
        else:
            return False, 'Incorrect password', None, None
    else:
        return False, 'User not found', None, None

#--------------------------------------- games

def add_game(name, size, price, description, banner_image, screenshot_image, game_profile, total_downloads=0):
    conn = get_db_connection()
    cursor = conn.cursor()
    query = """
        INSERT INTO games (name, size, price, description, banner_image, screenshot_image, game_profile, total_downloads)
        VALUES (%s, %s, %s, %s, %s, %s, %s, %s)
    """
    values = (name, size, price, description, banner_image, screenshot_image, game_profile, total_downloads)
    cursor.execute(query, values)
    conn.commit()
    cursor.close()
    conn.close()

def get_all_games():
    conn = get_db_connection()
    cursor = conn.cursor(dictionary=True)  
    query = "SELECT * FROM games"
    cursor.execute(query)
    games = cursor.fetchall()
    cursor.close()
    conn.close()
    return games

def update_game(game_id, name, size, price, description, banner_image, screenshot_image, game_profile, total_downloads):
    conn = get_db_connection()
    cursor = conn.cursor()
    cursor.execute("SELECT * FROM games WHERE id = %s", (game_id,))
    existing = cursor.fetchone()

    if not banner_image:
        banner_image = existing['banner_image']
    if not screenshot_image:
        screenshot_image = existing['screenshot_image']
    if not game_profile:
        game_profile = existing['game_profile']

    query = """
        UPDATE games
        SET name = %s,
            size = %s,
            price = %s,
            description = %s,
            banner_image = %s,
            screenshot_image = %s,
            game_profile = %s,
            total_downloads = %s
        WHERE id = %s
    """
    values = (
        name, size, price, description,
        banner_image, screenshot_image, game_profile,
        total_downloads, game_id
    )
    cursor.execute(query, values)
    conn.commit()
    cursor.close()
    conn.close()

def delete_game(game_id):
    conn = get_db_connection()
    cursor = conn.cursor()

    cursor.execute("SELECT * FROM games WHERE id = %s", (game_id,))
    game = cursor.fetchone()

    if not game:
        cursor.close()
        conn.close()
        return False

    cursor.execute("DELETE FROM games WHERE id = %s", (game_id,))
    conn.commit()
    cursor.close()
    conn.close()
    return True



def get_game_by_id(game_id):
    conn = get_db_connection()
    cursor = conn.cursor(dictionary=True)
    query = "SELECT * FROM games WHERE id = %s"
    cursor.execute(query, (game_id,))
    game = cursor.fetchone()
    cursor.close()
    conn.close()
    return game

