import os
from flask import Flask, request, jsonify, send_from_directory
from werkzeug.utils import secure_filename
from flask_cors import CORS
import socket
import future_crud
import hashlib

app = Flask(__name__)
CORS(app)

def hash_password(password):
    return hashlib.sha256(password.encode()).hexdigest()

UPLOAD_FOLDER = 'uploads'
app.config['UPLOAD_FOLDER'] = UPLOAD_FOLDER

# สร้างโฟลเดอร์ uploads ถ้ายังไม่มี
if not os.path.exists(UPLOAD_FOLDER):
    os.makedirs(UPLOAD_FOLDER)

# Route สำหรับเสิร์ฟไฟล์จากโฟลเดอร์ uploads
@app.route('/uploads/<path:filename>')
def uploaded_file(filename):
    return send_from_directory(app.config['UPLOAD_FOLDER'], filename)

# Register user 
@app.route('/register', methods=['POST'])
def register_user():
    data = request.json
    future_crud.register_user(
        data['email'],
        data['password'],
        data['username']
    )
    return jsonify({'message': 'User registered successfully'}), 201

#edit user
@app.route('/update_user', methods=['POST'])
def update_profile():
    email = request.form.get('email')
    new_email = request.form.get('new_email')
    new_username = request.form.get('new_username')
    new_password = request.form.get('new_password')
    new_picture = request.files.get('profile_picture')

    if not email:
        return jsonify({'message': 'Email is required'}), 400

    user_id = future_crud.get_user_id_by_email(email)
    if not user_id:
        return jsonify({'message': 'User not found'}), 404

    update_data = {}

    # ฟิลด์ที่อัปเดต
    if new_email:
        update_data['email'] = new_email
    if new_username:
        update_data['username'] = new_username
    if new_password:
        update_data['password'] = hash_password(new_password)

    # ฟิลด์รูปภาพ
    profile_picture_filename = None
    if new_picture:
        profile_picture_filename = secure_filename(new_picture.filename)
        upload_path = os.path.join(UPLOAD_FOLDER, profile_picture_filename)
        new_picture.save(upload_path)
        update_data['profile_picture'] = profile_picture_filename   # ✅ เก็บชื่อรูปใหม่ในฐานข้อมูล

    # อัปเดตลงฐานข้อมูล
    if update_data:
        future_crud.update_user_profile(user_id, update_data)

    return jsonify({
        'message': 'Profile updated successfully',
        'profile_picture': profile_picture_filename  # ✅ ส่งกลับชื่อไฟล์ใหม่
    }), 200



# Login user
@app.route('/login', methods=['POST'])
def login_user_api():
    data = request.json
    hashed_password = hash_password(data['password'])
    success, result, username, profile_picture = future_crud.login_user(data['email'], data['password'])
    if success:
        return jsonify({
            'token': result,  # ส่ง token ที่สร้างขึ้น
            'username': username,
            'profile_picture': profile_picture,
            'email': data['email'],
            'password': hashed_password
        }), 200
    else:
        return jsonify({'message': result}), 401

# ----------------------------------------- games ---------------------------------------
# Add games
@app.route('/add_game', methods=['POST'])
def add_game():
    try:
        # รับข้อมูลจากฟอร์ม
        game_name = request.form.get('game_name')
        size = request.form.get('size', '')
        price = request.form.get('price', '0')
        description = request.form.get('description', '')
        total_downloads = request.form.get('total_downloads', '0')

        if price == '0' or price == '' or price == 'free':
            price = None
        else:
            price = float(price)

        # รับไฟล์ภาพ
        banner_image = request.files.get('banner_image')
        screenshot_files = request.files.getlist('screenshot_image')  # <-- เปลี่ยนตรงนี้
        game_profile = request.files.get('game_profile')

        def save_file(file):
            if file:
                filename = secure_filename(file.filename)
                path = os.path.join(app.config['UPLOAD_FOLDER'], filename)
                file.save(path)
                return path
            return ''

        # บันทึกภาพ
        banner_path = save_file(banner_image)
        profile_path = save_file(game_profile)

        # บันทึกหลาย screenshot
        screenshot_paths = []
        for file in screenshot_files:
            path = save_file(file)
            if path:
                screenshot_paths.append(path)

        # รวมพาธรูป screenshot เป็น string เพื่อเก็บใน database
        screenshot_paths_str = ','.join(screenshot_paths)

        # ส่งข้อมูลเข้า future_crud
        future_crud.add_game(
            name=game_name,
            size=size,
            price=price,
            description=description,
            banner_image=banner_path,
            screenshot_image=screenshot_paths_str,  # เก็บหลายรูป
            game_profile=profile_path,
            total_downloads=total_downloads
        )

        return jsonify({'message': 'Game added successfully'}), 201

    except Exception as e:
        return jsonify({'error': str(e)}), 500


# select games
@app.route('/games', methods=['GET'])
def get_all_games():
    try:
        games = future_crud.get_all_games()

        if games:
            return jsonify({'games': games}), 200
        else:
            return jsonify({'message': 'No games found'}), 404
    except Exception as e:
        return jsonify({'error': str(e)}), 500


# update games
@app.route('/edit_game/<int:game_id>', methods=['PUT'])
def edit_game(game_id):
    try:
        # เชื่อมต่อกับฐานข้อมูลเพื่อดึงข้อมูลเดิม
        game = future_crud.get_game_by_id(game_id)

        # รับข้อมูลจากฟอร์ม ถ้ามีการส่งมาใหม่
        game_name = request.form.get('game_name', game['name'])  
        size = request.form.get('size', game['size'])
        price = request.form.get('price', game['price'])
        description = request.form.get('description', game['description'])
        total_downloads = request.form.get('total_downloads', game['total_downloads'])

        # ตรวจสอบว่า price เป็น '0', '', หรือ 'free' และตั้งค่าให้เป็น None
        if price == '0' or price == '' or price == 'free':
            price = None
        else:
            price = float(price)

        # รับไฟล์ภาพ ถ้ามีการส่งมาใหม่
        banner_image = request.files.get('banner_image')
        screenshot_files = request.files.getlist('screenshot_image')  # เปลี่ยนเป็น getlist
        game_profile = request.files.get('game_profile')

        # ฟังก์ชันบันทึกไฟล์
        def save_file(file, current_path):
            if file:
                filename = secure_filename(file.filename)
                path = os.path.join(app.config['UPLOAD_FOLDER'], filename)
                file.save(path)
                return path
            return current_path

        # อัปเดตไฟล์ถ้ามีการส่งไฟล์ใหม่มา
        banner_path = save_file(banner_image, game['banner_image'])
        profile_path = save_file(game_profile, game['game_profile'])

        # จัดการหลาย screenshot
        if screenshot_files and screenshot_files[0].filename != '':
            # มีการอัปโหลดใหม่
            screenshot_paths = []
            for file in screenshot_files:
                path = save_file(file, '')
                if path:
                    screenshot_paths.append(path)
            # รวมพาธรูป screenshot ใหม่ทั้งหมดเป็น string
            screenshot_paths_str = ','.join(screenshot_paths)
        else:
            # ไม่มีอัปโหลดใหม่ ใช้ข้อมูลเก่า
            screenshot_paths_str = game['screenshot_image']

        # อัปเดตข้อมูลในฐานข้อมูล
        future_crud.update_game(
            game_id=game_id,
            name=game_name,
            size=size,
            price=price,
            description=description,
            banner_image=banner_path,
            screenshot_image=screenshot_paths_str,
            game_profile=profile_path,
            total_downloads=total_downloads
        )

        return jsonify({'message': 'Game updated successfully'}), 200

    except Exception as e:
        return jsonify({'error': str(e)}), 500


# delete game by id
@app.route('/delete_game/<int:game_id>', methods=['DELETE'])
def delete_game(game_id):
    try:
        success = future_crud.delete_game(game_id)

        if success:
            return jsonify({'message': f'Game with ID {game_id} deleted successfully'}), 200
        else:
            return jsonify({'message': f'Game with ID {game_id} not found'}), 404

    except Exception as e:
        return jsonify({'error': str(e)}), 500



# get a specific game by id
@app.route('/get_game/<int:game_id>', methods=['GET'])
def get_game(game_id):
    try:
        game = future_crud.get_game_by_id(game_id)

        if game:
            return jsonify(game), 200
        else:
            return jsonify({'message': 'Game not found'}), 404

    except Exception as e:
        return jsonify({'error': str(e)}), 500
    



if __name__ == '__main__':
    # Get your local IP address
    hostname = socket.gethostname()
    local_ip = socket.gethostbyname(hostname)
    
    print(f"\n Flask is running! Open in browser:")
    print(f"    http://{local_ip}:5000/\n")
    
    app.run(debug=True, host='0.0.0.0', port=5000)
