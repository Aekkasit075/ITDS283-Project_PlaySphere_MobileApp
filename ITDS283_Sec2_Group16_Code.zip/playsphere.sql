create database playsphere;
use playsphere;

CREATE TABLE users (
    id INT AUTO_INCREMENT PRIMARY KEY,
    email VARCHAR(100),
    password VARCHAR(255),
    username VARCHAR(50),
    profile_picture TEXT 
);

TRUNCATE TABLE users;
select * from users;
delete from users where id = 2;

CREATE TABLE games (
    id INT AUTO_INCREMENT PRIMARY KEY,
    name VARCHAR(255) NOT NULL,
    size VARCHAR(50),
    price DECIMAL(10,2) DEFAULT NULL,
    total_downloads VARCHAR(50) DEFAULT 0,
    description TEXT,
    banner_image VARCHAR(255),
    screenshot_image VARCHAR(255),
    game_profile VARCHAR(255),
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

TRUNCATE TABLE games;
drop table games;
select * from games;


ALTER TABLE games DROP COLUMN user_id;
SHOW CREATE TABLE games;
ALTER TABLE games DROP FOREIGN KEY fk_user_id;

--
ALTER TABLE games ADD COLUMN user_id INT;

ALTER TABLE games
ADD CONSTRAINT fk_user_id
FOREIGN KEY (user_id) REFERENCES users(id)
ON DELETE CASCADE;

SELECT user_id, COUNT(*) AS game_count
FROM games
GROUP BY user_id;





